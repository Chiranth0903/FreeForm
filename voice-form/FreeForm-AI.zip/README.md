# FreeForm AI

Version 1.2.2: yes/no confirmations act immediately on the first recognized word, including interim recognition. Ordinary field answers wait about 1.4 seconds after a final result, or 2.2 seconds after an interim result. Repeated yes/no words are accepted; unrecognized confirmation speech preserves the original pending answer instead of replacing it. Reload the extension and click its icon; the heading should say FreeForm AI 1.2.2.

Chrome extension for this form:
https://form.123formbuilder.com/7008640/health-insurance-enrollment-form

## Install
1. Open chrome://extensions in Chrome.
2. Enable Developer mode.
3. Click Load unpacked and choose C:\chiranth\projects\freeform\voice-form\extension
4. Open the enrollment form, open Chrome's Extensions menu, and click FreeForm AI.
5. Click Start conversation and allow microphone access to the website when asked.

## Use
Click Start conversation once. Wait for the spoken question, then answer. The assistant asks "I heard Chiranth. Is that correct?" Say `yes` to fill it and move to the next question, or `no` to repeat that field. Listening resumes automatically after questions and after Chrome ends an empty recognition session. The microphone pauses while the assistant speaks to avoid hearing itself. Multiword answers are collected until a short pause (about 1.4 seconds after a final speech result).

Choose English India, US, or UK to match your speech. Pause stops recording and speech; Resume conversation continues. A denied microphone permission or repeated speech-service connection failure pauses the guide and shows a recovery message. Chrome's microphone indicator may turn off between questions; this is expected while the assistant speaks.
Commands: skip, back, stop, undo, go to FIELD, change FIELD to VALUE.
Choose a field from the dropdown when labels are ambiguous. Use the typed answer box if recognition gets spelling wrong. Say `change Last to BK` to correct another field; the assistant confirms the edit before applying it.

## Updating an installed copy
At chrome://extensions, click Reload on FreeForm AI, then click the extension toolbar icon again. Version 1.2.1 replaces an older panel automatically and displays FreeForm AI 1.2.1 in its heading. Refresh the form tab only if the previous version remains visible (refreshing may clear entered answers).

Version 1.2.1 fixes browser timer receiver binding, requests microphone permission directly from Start, resumes suspended speech playback, and falls back to listening if speech playback stalls. Startup exceptions are shown in the panel instead of leaving an inert Start button. Spoken questions are enabled for the conversation.

## Automated verification
Run `node --test voice-form/test.cjs voice-form/voice-session.test.cjs` from the project folder. Tests cover speech turn timing, multiple words, unexpected recognition endings, empty-session restart, cancellation, denied permissions, date parsing, and the first-name/yes/last-name/no/retry/yes conversation. These use simulated speech events; a real microphone test is still needed.
Email example: alex at example dot com. Dates accept YYYY-MM-DD or unambiguous spoken dates such as 15 October 2005. Ambiguous numeric dates are rejected rather than guessed.
Select and radio answers must match the listed choices. Checkboxes accept yes/no.
Review the actual page before submitting. The extension never submits a form.

## Local demo
Run `node voice-form/serve.cjs` from the project folder, then open http://127.0.0.1:8765 in Chrome. Use fictional details.

## Scope and limitations
Only the specified enrollment URL and localhost are enabled. No API keys, dependencies, analytics, answer persistence, or backend are used. Chrome speech recognition may send audio to its recognition provider and may require internet. Microphone access is granted to the current website because recognition runs on that page. Test with fictional details first.
Standard visible HTML inputs, textareas, selects, radio groups, and checkboxes are supported. Custom widgets, iframes, shadow DOM, signatures, uploads, passwords, and conditional/multi-page form sections need manual handling or a rescan. Click Rescan after the page reveals new fields. Natural language commands use deterministic matching rather than an LLM.

The live website was inspected through Chrome accessibility on 26 November 2026. It contains Employee name (First/Last), Date of birth (custom MM/DD/YYYY segments), Mailing address (Street Address/City/Region/Postal-Zip Code), Email address, Insurance plan (Individual/Family/Group), and reCAPTCHA. Segmented dates are handled when the widget exposes editable inputs or contenteditable segments; other custom segments require manual entry. CAPTCHA is always manual. End-to-end filling and actual microphone recognition have not been verified; speech accuracy depends on the microphone, pronunciation, network, and Chrome recognition service. No numerical accuracy claim has been measured.
